<?php
$link1=$_REQUEST['update'];
?>
<html>
<head>
<script>
function myfunction1()
{
	document.getElementById("update").click();
}
</script>
</head>
<body onLoad="myfunction1()">
<form action="update_msg.php" method="post" id="myform">
	<input hidden="" type="text" name="update" value="<?php echo"$link1";?>">
    <button hidden="" type="submit" id="update" data-modal="update" name="update" value="update"></button>
</form>

<h1 style="padding-left:400px; padding-top:200px;"><img src="../images/loading-x.gif" /></h1>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>